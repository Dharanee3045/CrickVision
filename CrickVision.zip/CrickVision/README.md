# CrickVision — IPL Player Analysis, Team Compatibility & Win Prediction

## Pages in the Streamlit dashboard

1. **Player Leaderboard** — role-filtered player rankings and impact scores.
2. **Player Search** — batting/bowling statistics, death-over batting run rate, death-over bowling statistics, and base-price-to-predicted-sold-value prototype.
3. **Team Builder** — select 11 players per side, inspect team strength, and view candidate player-fit recommendations for each squad.
4. **Win Prediction** — a separate page that uses the two saved Playing XIs, venue, toss winner and toss decision with the existing Random Forest model.

## Files

| File | Purpose |
|---|---|
| `01_load_and_explore.py` | Inspect source CSVs |
| `02_data_cleaning.py` | Clean and normalize match/delivery data |
| `03_player_analysis.py` | Build player statistics, impact scores, role heuristics and death-over metrics |
| `04_train_win_model.py` | Train and save the Random Forest win predictor and encoders |
| `05_app.py` | Streamlit dashboard |
| `deliveries_clean.csv`, `matches_clean.csv` | Cleaned historical IPL data |
| `player_scores.csv` | Generated player statistics and impact scores |
| `player_bio.csv` | Available player biography information |

## Setup and run

Open Command Prompt in this folder. Ensure Python is installed and `py --version` works, then run:

```cmd
py -m pip install -r requirements.txt
py 03_player_analysis.py
py 04_train_win_model.py
py -m streamlit run 05_app.py
```

If the raw CSVs have changed and you want to rebuild the clean data, run `01_load_and_explore.py` and `02_data_cleaning.py` first.

## Optional verified role overrides

You may add `player_roles.csv` with two columns, `player,role`. Accepted roles are Batsman, Bowler and All-Rounder. Exact player-name matching is used, and this file overrides the heuristic role only for listed players. Keep role labels sourced/verified rather than guessing.

## Auction-price limitation — read before presenting

The supplied project ZIP does **not** contain a historical auction table with player, season, base price, actual sold price and unsold status. Therefore, the dashboard's “Performance-based Predicted Sold Value” is currently a transparent heuristic prototype, not a trained or validated auction-price ML model. The base price is a user-selected input. To train a credible sold-price model, supply auction-history data and evaluate predictions against held-out actual sold prices.

## Compatibility-score limitation — read before presenting

Player Team Fit Scores are heuristic recommendations based on role balance, Overall Impact Score and available death-over batting/bowling metrics. They are not win probabilities or proven player-pair chemistry. They should be described as a prototype until validated against historical squad outcomes.

## Death-over run rate

The profile displays batter-specific scoring rate calculated as `6 × death-over runs / recorded balls faced`. This is separate from strike rate and uses the delivery dataset's death-over records. The data's over numbering is 0–19, so the analysis maps overs 15–19 to overs 16–20 in cricket notation.


## Player display names
Names are expanded using the curated mapping in `player_name_map.csv`. Uncertain initials are flagged for review instead of guessed.
