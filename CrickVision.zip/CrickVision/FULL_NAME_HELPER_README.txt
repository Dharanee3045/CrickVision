FULL PLAYER NAME COMPLETION HELPER

This helper uses the official Cricsheet People Register and alternate-name register.
Extract the ZIP, open the CrickVision folder in CMD, then run:
  py complete_player_names.py

It requires an internet connection and may require permission to overwrite CSV files. Back up the folder first. It resolves only exact, unique register matches and leaves ambiguous identities marked for review rather than inventing full names. It then attempts to regenerate player_scores.csv using 03_player_analysis.py.

Reference: https://cricsheet.org/register/ (register includes people.csv and names.csv with name variants).
